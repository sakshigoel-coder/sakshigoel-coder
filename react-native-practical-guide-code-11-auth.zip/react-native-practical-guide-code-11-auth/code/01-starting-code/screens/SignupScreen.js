import AuthContent from '../components/Auth/AuthContent';

function SignupScreen() {
  return <AuthContent />;
}

export default SignupScreen;
